var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Cakes' });
});

module.exports = router;


// כאשר המשתמש נכנס לעמוד
// localhost:3000/pixa 
// יוצג לו אפשרות חיפוש כמו במוזיקה שעשינו
// החיפוש ישגר את המשתמש לפי חיפוש התמונה לכתובת
// localhost:3000/pixa/list/?q=cats

//וכמובן יוצג למשתמש תמונות של חתולים או החיפוש שהוא ביצע