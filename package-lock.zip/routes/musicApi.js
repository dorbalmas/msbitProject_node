const express = require('express');
const axios = require("axios");
const router = express.Router();

// בשביל בדיקות לפעמים כדי לראות שהכתובת 
// או הקוד נכון שמים את הקוד באוויר ולא בגיט
// let url = "https://deezerdevs-deezer.p.rapidapi.com/search?rapidapi-key=0553c29e4bmsh3a239d5a07dbdb4p1e9ae1jsnc9399dacde13&q=abba";
// axios.get(url)
// .then(resp => {
//   console.log(resp.data.data)
// })



/* GET home page. */
router.get('/', (req, res) => {
  let searchQ = req.query.q;
  let url = "https://deezerdevs-deezer.p.rapidapi.com/search?rapidapi-key=0553c29e4bmsh3a239d5a07dbdb4p1e9ae1jsnc9399dacde13&q="+searchQ;
  axios.get(url)
  .then(resp => {
    // console.log(resp.data.data)
    let myData = resp.data.data
    res.render('music', { title: 'Monkeys music', _ar:myData });
  })
});

router.get('/search', (req, res) => {
  res.render('music_search', { });
});
module.exports = router;

//https://deezerdevs-deezer.p.rapidapi.com/search?rapidapi-key=0553c29e4bmsh3a239d5a07dbdb4p1e9ae1jsnc9399dacde13&q=abba
