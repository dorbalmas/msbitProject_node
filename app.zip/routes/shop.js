var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('Shop', { _ar:shop_ar });
});

router.get('/:prodId', function(req, res) {
  let myId = req.params.prodId;
  res.render('shop_prod', { item:shop_ar[myId]});
});

module.exports = router;




let shop_ar = [
  {
  "cat": "food",
  "name": "Milk",
  "price": "6",
  "image": "https://cdn.pixabay.com/photo/2017/07/05/15/41/milk-2474993_150.jpg"
  },
  {
  "cat": "food",
  "name": "Bread",
  "price": "8",
  "image": "https://cdn.pixabay.com/photo/2014/07/22/09/59/bread-399286_150.jpg"
  },
  {
  "cat": "food",
  "name": "Eggs",
  "price": "12",
  "image": "https://cdn.pixabay.com/photo/2015/09/17/17/19/egg-944495_150.jpg"
  },
  {
  "cat": "clothing",
  "name": "Coat",
  "price": "120",
  "image": "https://cdn.pixabay.com/photo/2015/05/29/19/19/person-789663_150.jpg"
  },
  {
  "cat": "clothing",
  "name": "Dress",
  "price": "4000",
  "image": "https://cdn.pixabay.com/photo/2016/06/29/04/17/wedding-dresses-1485984_150.jpg"
  },
  {
  "cat": "clothing",
  "name": "Shirt",
  "price": "70",
  "image": "https://cdn.pixabay.com/photo/2014/08/05/10/31/waiting-410328_150.jpg"
  },
  {
  "cat": "animals",
  "name": "Dog food",
  "price": "70",
  "image": "https://cdn.pixabay.com/photo/2017/04/07/10/53/dog-2210717_150.jpg"
  },
  {
  "cat": "animals",
  "name": "Cat toy",
  "price": "50",
  "image": "https://cdn.pixabay.com/photo/2018/07/21/09/17/cat-3552143_150.jpg"
  }
  ]